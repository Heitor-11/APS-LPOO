package com.example.recyclinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Herói da Reciclagem - versão com tipos de lixo e lixeiras específicas.
 *
 * Conceitos de LPOO demonstrados nesta versão:
 * - Abstração: a classe abstrata Trash define o "molde" comum de todo lixo.
 * - Herança: PaperTrash, PlasticTrash e OrganicTrash herdam de Trash.
 * - Polimorfismo: draw() e move() são executados de forma diferente para
 *   cada subtipo através da sobrescrita de getColor() e getType().
 * - Encapsulamento: atributos protegidos/privados, acesso via métodos.
 * - Composição: RecyclingGame "contém" listas de Trash e de TrashBin.
 */
public class RecyclingGame extends JPanel {

    private static final int PANEL_WIDTH = 800;
    private static final int PANEL_HEIGHT = 650;
    private static final int BIN_Y = 580;
    private static final int BIN_HEIGHT = 60;

    private int score = 0;
    private Timer gameTimer;
    private final List<Trash> trashItems = new ArrayList<>();
    private final List<TrashBin> bins = new ArrayList<>();
    private final Random random = new Random();

    // Controle do item sendo arrastado pelo jogador
    private Trash draggedTrash = null;
    private int dragOffsetX, dragOffsetY;

    // Mensagem de feedback ("Correto!" / "Lixeira errada!")
    private String feedbackMessage = "";
    private Color feedbackColor = Color.BLACK;
    private int feedbackTicks = 0;

    public RecyclingGame() {
        setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
        setBackground(Color.CYAN);

        criarLixeiras();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                selecionarLixoParaArrastar(e.getPoint());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                soltarLixo();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                arrastarLixo(e.getPoint());
            }
        });

        gameTimer = new Timer(1000 / 60, e -> gameLoop());
        gameTimer.start();
    }

    /** Cria as três lixeiras fixas na parte inferior da tela. */
    private void criarLixeiras() {
        bins.add(new TrashBin(10, BIN_Y, 250, BIN_HEIGHT,
                TrashType.PAPEL, new Color(30, 90, 200), "PAPEL"));
        bins.add(new TrashBin(275, BIN_Y, 250, BIN_HEIGHT,
                TrashType.PLASTICO, new Color(200, 30, 30), "PLÁSTICO"));
        bins.add(new TrashBin(540, BIN_Y, 250, BIN_HEIGHT,
                TrashType.ORGANICO, new Color(90, 60, 20), "ORGÂNICO"));
    }

    private void selecionarLixoParaArrastar(Point click) {
        for (int i = trashItems.size() - 1; i >= 0; i--) {
            Trash trash = trashItems.get(i);
            if (trash.getBounds().contains(click)) {
                draggedTrash = trash;
                dragOffsetX = click.x - trash.getX();
                dragOffsetY = click.y - trash.getY();
                break;
            }
        }
    }

    private void arrastarLixo(Point mousePos) {
        if (draggedTrash != null) {
            draggedTrash.setPosition(mousePos.x - dragOffsetX, mousePos.y - dragOffsetY);
            repaint();
        }
    }

    private void soltarLixo() {
        if (draggedTrash == null) {
            return;
        }

        TrashBin lixeiraAlvo = null;
        for (TrashBin bin : bins) {
            if (bin.getBounds().intersects(draggedTrash.getBounds())) {
                lixeiraAlvo = bin;
                break;
            }
        }

        if (lixeiraAlvo != null) {
            if (lixeiraAlvo.accepts(draggedTrash)) {
                score++;
                mostrarFeedback("Correto! +1", new Color(0, 130, 0));
            } else {
                score = Math.max(0, score - 1);
                mostrarFeedback("Lixeira errada! -1", new Color(160, 0, 0));
            }
            trashItems.remove(draggedTrash);
        }
        // Se não soltou sobre nenhuma lixeira, o item continua caindo normalmente.

        draggedTrash = null;
    }

    private void mostrarFeedback(String mensagem, Color cor) {
        feedbackMessage = mensagem;
        feedbackColor = cor;
        feedbackTicks = 60; // ~1 segundo a 60 FPS
    }

    private void gameLoop() {
        if (random.nextInt(100) < 2) {
            trashItems.add(criarLixoAleatorio());
        }

        for (Trash trash : trashItems) {
            if (trash != draggedTrash) {
                trash.move();
            }
        }

        // Item que passou da área das lixeiras sem ser descartado corretamente é perdido.
        trashItems.removeIf(trash -> trash != draggedTrash && trash.getY() > BIN_Y + BIN_HEIGHT);

        if (feedbackTicks > 0) {
            feedbackTicks--;
        }

        repaint();
    }

    /** Fábrica simples que sorteia qual subtipo de lixo será criado (demonstra polimorfismo). */
    private Trash criarLixoAleatorio() {
        int x = random.nextInt(PANEL_WIDTH - 30);
        int tipo = random.nextInt(3);
        switch (tipo) {
            case 0:
                return new PaperTrash(x, 0);
            case 1:
                return new PlasticTrash(x, 0);
            default:
                return new OrganicTrash(x, 0);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (TrashBin bin : bins) {
            bin.draw(g);
        }

        for (Trash trash : trashItems) {
            trash.draw(g);
        }

        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        g.drawString("Pontuação: " + score, 10, 30);

        g.setFont(new Font("Arial", Font.PLAIN, 14));
        g.drawString("Arraste o lixo até a lixeira correta", 10, 55);

        if (feedbackTicks > 0) {
            g.setColor(feedbackColor);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString(feedbackMessage, PANEL_WIDTH / 2 - 80, 40);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Herói da Reciclagem");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.add(new RecyclingGame());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

/** Tipos de lixo suportados pelo jogo. */
enum TrashType {
    PAPEL,
    PLASTICO,
    ORGANICO
}

/**
 * Classe abstrata que representa um item de lixo genérico caindo na tela.
 * Define o comportamento comum (queda, desenho, colisão) e deixa a cor e o
 * tipo específico para cada subclasse implementar (polimorfismo).
 */
abstract class Trash {
    protected int x, y;
    protected final int size = 30;

    public Trash(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract Color getColor();

    public abstract TrashType getType();

    public void move() {
        y += 2;
    }

    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillRect(x, y, size, size);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, size, size);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, size, size);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
}

/** Lixo do tipo papel. */
class PaperTrash extends Trash {
    public PaperTrash(int x, int y) {
        super(x, y);
    }

    @Override
    public Color getColor() {
        return new Color(30, 90, 200); // azul, mesma cor da lixeira de papel
    }

    @Override
    public TrashType getType() {
        return TrashType.PAPEL;
    }
}

/** Lixo do tipo plástico. */
class PlasticTrash extends Trash {
    public PlasticTrash(int x, int y) {
        super(x, y);
    }

    @Override
    public Color getColor() {
        return new Color(200, 30, 30); // vermelho, mesma cor da lixeira de plástico
    }

    @Override
    public TrashType getType() {
        return TrashType.PLASTICO;
    }
}

/** Lixo do tipo orgânico. */
class OrganicTrash extends Trash {
    public OrganicTrash(int x, int y) {
        super(x, y);
    }

    @Override
    public Color getColor() {
        return new Color(90, 60, 20); // marrom, mesma cor da lixeira orgânica
    }

    @Override
    public TrashType getType() {
        return TrashType.ORGANICO;
    }
}

/** Representa uma lixeira fixa na parte inferior da tela, aceitando apenas um tipo de lixo. */
class TrashBin {
    private final int x, y, width, height;
    private final TrashType acceptedType;
    private final Color color;
    private final String label;

    public TrashBin(int x, int y, int width, int height,
                     TrashType acceptedType, Color color, String label) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.acceptedType = acceptedType;
        this.color = color;
        this.label = label;
    }

    public boolean accepts(Trash trash) {
        return trash.getType() == acceptedType;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, width, height);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, width, height);

        g.setFont(new Font("Arial", Font.BOLD, 14));
        FontMetrics fm = g.getFontMetrics();
        int textX = x + (width - fm.stringWidth(label)) / 2;
        int textY = y + height / 2 + fm.getAscent() / 2;
        g.setColor(Color.WHITE);
        g.drawString(label, textX, textY);
    }
}
