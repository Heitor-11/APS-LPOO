#!/bin/bash
# Herói da Reciclagem - compila e executa o jogo (Linux / macOS)
cd "$(dirname "$0")" || exit 1

if ! command -v javac >/dev/null 2>&1; then
  echo "ERRO: o JDK (javac) nao foi encontrado."
  echo "Instale o JDK 17 ou superior e rode este script novamente."
  echo "Veja o arquivo PASSO_A_PASSO.txt, Parte 1."
  exit 1
fi

echo "Compilando..."
rm -rf out && mkdir out
javac -encoding UTF-8 -d out src/com/example/recyclinggame/RecyclingGame.java || { echo "ERRO na compilacao."; exit 1; }

echo "Iniciando o jogo (feche a janela para encerrar)..."
java -cp out com.example.recyclinggame.RecyclingGame
