@echo off
chcp 65001 >nul
REM Heroi da Reciclagem - compila e executa o jogo (Windows)
cd /d "%~dp0"

where javac >nul 2>nul
if errorlevel 1 (
  echo ERRO: o JDK ^(javac^) nao foi encontrado.
  echo Instale o JDK 17 ou superior e execute este arquivo novamente.
  echo Veja o arquivo PASSO_A_PASSO.txt, Parte 1.
  pause
  exit /b 1
)

echo Compilando...
if exist out rmdir /s /q out
mkdir out
javac -encoding UTF-8 -d out src\com\example\recyclinggame\RecyclingGame.java
if errorlevel 1 (
  echo ERRO na compilacao.
  pause
  exit /b 1
)

echo Iniciando o jogo ^(feche a janela para encerrar^)...
java -cp out com.example.recyclinggame.RecyclingGame
pause
